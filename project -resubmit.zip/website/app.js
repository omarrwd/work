// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth() + '.' + d.getDate() + '.' + d.getFullYear();
//get all data
function get_data() {
    try {
        let user_zip = document.getElementById("zip").value
        let url = `https://api.openweathermap.org/data/2.5/weather?zip=${user_zip},&appid=734ba01c6282d50841612ad8036ea358`
        let feelings_of_user = document.getElementById("feelings").value
        fetch(url)
            .then(function(resp) { return resp.json() })
            .then(function(data) {
                const all_information = {
                    newDate,
                    the_city: data.name,
                    temperature: data.main.temp,
                    description_of_weather: data.weather[0].description,
                    feelings_of_user,
                };
                post("/add", all_information);
                retrieveData()
            })
    } catch (error) {
        console.log(error);
    }
}

document.getElementById("generate").addEventListener("click", get_data)
    //post data
const post = async(url, all_information) => {
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(all_information),
    });

    try {
        const newData = await res.json();
        return newData;
    } catch (error) {
        console.log(error);
    }
};
// retrieveData
const retrieveData = async() => {
    const request = await fetch('/all');
    try {
        const allData = await request.json()
        let celcius = Math.round(parseFloat(allData.temperature) - 273.15);
        console.log(allData)
        document.getElementById('temp').innerHTML = celcius + " " + 'degrees';
        document.getElementById("city").innerHTML = allData.the_city;
        document.getElementById("date").innerHTML = allData.newDate;
        document.getElementById("description").innerHTML = allData.description_of_weather;
        document.getElementById("content").innerHTML = allData.feelings_of_user;

    } catch (error) {
        console.log("error", error);
    }
}