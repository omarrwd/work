# Weather-Journal App Project

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI. 

## develoment
I used what I learned in this course with new information like url and how to use it. And how to use get and post and asynchronous JavaScript, so I made an application to find out the temperatures in the United States of America 
