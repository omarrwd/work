<?php
require_once("delete_database.php");

try {
    $query = "SELECT id, namee, email, addresss, gender FROM user";
    $prepared = $conn->prepare($query);
    $prepared->execute();
    $result = $prepared->fetchAll(PDO::FETCH_ASSOC);
?>
    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>email</th>
                <th>address</th>
                <th>gender</th>

            </tr>
        </thead>
        <?php
        foreach ($result as $row) {

        ?>
            <tr>
                <td><?php echo $row['id']; ?> </td>
                <td><?php echo $row['namee']; ?> </td>
                <td><?php echo $row['email']; ?> </td>
                <td><?php echo $row['addresss']; ?> </td>
                <td><?php echo $row['gender']; ?> </td>
                <td>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <button type="submit" name="delete" value="<?= $row['id'] ?>">Delete</button>
                    </form>
                </td>
                <td>
                    <a href="update_table.php?id=<?= $row['id'] ?>">Edit</a>
                </td>
            </tr>
        <?php
        }
        ?>
    </table>
    <a href="form.php">
        <h1>back to main</h1>
    </a>

<?php
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>