<?php
// connect with database 
$servername = "localhost";
$username = "omarr";
$password = "123";
$dbname = "mydb";
try {
  $conn = new PDO("mysql:host=$servername;port=3307;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  echo $stmt . "<br>" . $e->getMessage();
}
//select users to put them in html table

try {
    $sql = "SELECT * FROM user";
    $sql2 = $conn->query($sql);
    //bring the inserted data
    $row = $sql2->fetch(PDO::FETCH_ASSOC);
  } catch (PDOException $e) {
    echo $e->getMessage();
  }
?>
<!-- ////////////////////////////////////////////////////////////// -->