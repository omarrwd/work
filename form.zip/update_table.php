<?php
require_once("validation.php");
require_once("update_database.php");
//the number of id to ubdate it
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query2 = "SELECT * FROM user WHERE id=? LIMIT 1";
    $statement2 = $conn->prepare($query2);
    $statement2->bindParam(1, $id, PDO::PARAM_INT);
    $statement2->execute();
    $data2 = $statement2->fetch(PDO::FETCH_ASSOC);
    // while ($data2 = $statement2->fetch(PDO::FETCH_ASSOC)) {
    //     $name2 = $data2['namee'];
    //     $email2 = $data2['email'];
    //     $address2 = $data2['addresss'];
    // }
}

?>
<!-- the form of update -->
<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <input type="hidden" name="id" value="<?=$data2['id'];?>">
    Name: <input type="text" name="name" value="<?=$data2['namee'];?>">
    <span class="error">* <?php echo $nameErr; ?></span>
    <br><br>
    E-mail: <input type="text" name="email" value="<?=$data2['email'];?>">
    <span class="error">* <?php echo $emailErr; ?></span>
    <br><br>
    Address: <input type="text" name="address" value="<?=$data2['addresss'];?>">
    <span class="error"><?php echo $addressErr; ?></span>
    <br><br>
    Gender:
    <input type="radio" name="gender" <?php if (isset($gender) && $gender == "female") echo "checked"; ?> value="female">Female
    <input type="radio" name="gender" <?php if (isset($gender) && $gender == "male") echo "checked"; ?> value="male">Male
    <span class="error">* <?php echo $genderErr; ?></span>
    <br><br>
    <input type="submit" name="update" value="Submit">
    <br><br>
</form>
</body>

</html>