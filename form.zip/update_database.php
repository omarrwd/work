<!-- sweet alert definition -->
<head>
    <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<?php
require_once("connect.php");

//updata database code

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name2 = $_POST['name'];
    $email2 = $_POST['email'];
    $address2 = $_POST['address'];
    $gender2 = $_POST['gender'];

    if (empty($name2) || empty($email2) || empty($gender2) || empty($address2)||!filter_var($name2, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH)||!preg_match("/^[a-zA-Z-' ]*$/", $name2) || !filter_var($email2, FILTER_VALIDATE_EMAIL)) {

            echo "you must write the edit in the same constrains of first form";
        
    } else {


        try {

            $query2 = "UPDATE user SET namee=:namee, email=:email, addresss=:addresss, gender=:gender WHERE id=:id LIMIT 1";
            $statement2 = $conn->prepare($query2);
            $statement2->bindParam(':namee', $name2);
            $statement2->bindParam(':email', $email2);
            $statement2->bindParam(':addresss', $address2);
            $statement2->bindParam(':gender', $gender2);
            $statement2->bindParam(':id', $id, PDO::PARAM_INT);
            $query_execute2 = $statement2->execute();

            if ($query_execute2) {
                echo "updated Successfully" . " " . '<a href="form.php">return to main page</a>' . '<script type="text/javascript">
                $(document).ready(function() {
                    swal({
                        title: "USER updated!",
                        text: "Suceess message sent!!",
                        icon: "success",
                        button: "Ok",
                        timer: 2000
                    });
                });
            </script>';
            exit(0);
            } else {
                echo "uptaded failed";
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
}
