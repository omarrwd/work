<?php
require_once("validation.php");
?>
<!-- ///////////////////////////////////////////////////////////////////////////////////////// -->
    <!-- create form -->
    <h2>PHP Form Validation Example</h2>
    <p><span class="error">* required field</span></p>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        Name: <input type="text" name="name" value="<?php echo $name; ?>">
        <span class="error">* <?php echo $nameErr; ?></span>
        <br><br>
        E-mail: <input type="text" name="email" value="<?php echo $email; ?>">
        <span class="error">* <?php echo $emailErr; ?></span>
        <br><br>
        Address: <input type="text" name="address" value="<?php echo $address; ?>">
        <span class="error"><?php echo $addressErr; ?></span>
        <br><br>
        Gender:
        <input type="radio" name="gender" <?php if (isset($gender) && $gender == "female") echo "checked"; ?> value="female">Female
        <input type="radio" name="gender" <?php if (isset($gender) && $gender == "male") echo "checked"; ?> value="male">Male
        <span class="error">* <?php echo $genderErr; ?></span>
        <br><br>
        <input type="submit" name="submit" value="Submit">
        <br><br>
    </form>
    <?php
    // send to mysqli...................................................
    if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["name"]) && !empty($_POST["email"]) && !empty($_POST["gender"]) && !empty($_POST["address"]) && preg_match("/^[a-zA-Z-' ]*$/", $name) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        require_once("insert.php"); 

        header("Location:table_of_users.php");

    }
    ?>

</body>

</html>