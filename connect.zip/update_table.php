<?php
require_once("validation.php");
require_once("connect.php");
//the number of id to ubdate it
if (isset($_GET['id'])) {
    $student_id = $_GET['id'];

    $query2 = "SELECT * FROM user WHERE id=? LIMIT 1";
    $statement2 = $conn->prepare($query2);
    $statement2->bindParam(1, $student_id, PDO::PARAM_INT);
    $statement2->execute();
    $data2 = $statement2->fetch(PDO::FETCH_ASSOC);
    while ($data2 = $statement2->fetch(PDO::FETCH_ASSOC)) {
        $name2 = $data2['namee'];
        $email2 = $data2['email'];
        $address2 = $data2['addresss'];
    }
}

?>

<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
<form method="post" action="delete_and_update_database.php">
    <input type="hidden" name="student_id" value="<?php echo $_GET['id'];?>">
    Name: <input type="text" name="name" value="<?php echo $name2 ?>">
    <span class="error">* <?php echo $nameErr; ?></span>
    <br><br>
    E-mail: <input type="text" name="email" value="<?php echo $email2; ?>">
    <span class="error">* <?php echo $emailErr; ?></span>
    <br><br>
    Address: <input type="text" name="address" value="<?php echo $address2; ?>">
    <span class="error"><?php echo $addressErr; ?></span>
    <br><br>
    Gender:
    <input type="radio" name="gender" <?php if (isset($gender) && $gender == "female") echo "checked"; ?> value="female">Female
    <input type="radio" name="gender" <?php if (isset($gender) && $gender == "male") echo "checked"; ?> value="male">Male
    <span class="error">* <?php echo $genderErr; ?></span>
    <br><br>
    <input type="submit" name="update" value="Submit">
    <br><br>
</form>
</body>

</html>