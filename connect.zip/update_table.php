<?php
//require statments
require_once("validation.php");
require_once("update_database.php");
//the number of id to ubdate it
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query2 = "SELECT * FROM user WHERE id=? LIMIT 1";
    $statement2 = $conn->prepare($query2);
    $statement2->bindParam(1, $id, PDO::PARAM_INT);
    $statement2->execute();
    $data2 = $statement2->fetch(PDO::FETCH_ASSOC);
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>edit form</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="">
</head>

<body>
    <!-- the form of update -->
    <h2>PHP Form edit </h2>
    <p><span class="error">* required field</span></p>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <!-- //input hidden to know the id of user -->
        <input type="hidden" name="id" value="<?= $data2['id']; ?>">
        Name: <input type="text" name="name" value="<?= (isset($data2['namee']) ? $data2['namee'] : ""); ?>">
        <span class="error">* <?php echo $nameErr; ?></span>
        <br><br>
        E-mail: <input type="text" name="email" value="<?= (isset($data2['email']) ? $data2['email'] : ""); ?>">
        <span class="error">* <?php echo $emailErr; ?></span>
        <br><br>
        Address: <input type="text" name="address" value="<?= (isset($data2['addresss']) ? $data2['addresss'] : ""); ?>">
        <span class="error"><?php echo $addressErr; ?></span>
        <br><br>
        Gender:
        <input type="radio" name="gender" <?php if (isset($gender) && $gender == "female") echo "checked"; ?> value="female">Female
        <input type="radio" name="gender" <?php if (isset($gender) && $gender == "male") echo "checked"; ?> value="male">Male
        <span class="error">* <?php echo $genderErr; ?></span>
        <br><br>
        <input type="submit" name="update" value="Submit">
        <br><br>
    </form>
</body>

</html>