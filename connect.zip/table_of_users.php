<?php require_once("insert.php"); ?>

<!-- table of database into html table -->
<!DOCTYPE html>
<html lang="en">

<head>
    <style>
        table,
        th,
        td {
            border-collapse: collapse;
            background-color: gray;
            border: 1px solid;
        }
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>

<body>
    <!-- display the inserted data into html table -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>email</th>
                <th>address</th>
                <th>gender</th>

            </tr>
        </thead>
        <?php while ($row = $sql2->fetch(PDO::FETCH_ASSOC)) : ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['namee']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['addresss']); ?></td>
                <td><?php echo htmlspecialchars($row['gender']); ?></td>
                <td>
                    <form action="delete_and_update_database.php" method="POST">
                        <button type="submit" name="delete" value="<?= $row['id'] ?>">Delete</button>
                    </form>
                </td>
                <td>
                    <a href="update_table.php?id=<?= $row['id'] ?>">Edit</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>

</html>