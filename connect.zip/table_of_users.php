<?php
//connect db
require_once("connect.php");

//display users from db into table
try {
    $query = "SELECT id, namee, email, addresss, gender FROM user";
    $prepared = $conn->prepare($query);
    $prepared->execute();
    $result = $prepared->fetchAll(PDO::FETCH_ASSOC);
?>
    <!-- table of inserted users -->
    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>email</th>
                <th>address</th>
                <th>gender</th>
                <th>delete</th>
                <th>edit</th>
            </tr>
        </thead>
        <?php
        //loop fo display users
        foreach ($result as $row) {

        ?>
            <tr>
                <td><?php echo $row['id']; ?> </td>
                <td><?php echo $row['namee']; ?> </td>
                <td><?php echo $row['email']; ?> </td>
                <td><?php echo $row['addresss']; ?> </td>
                <td><?php echo $row['gender']; ?> </td>
                <td>
                    <!-- delete button -->
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <!-- input type hidden to execute delete button if we submit it -->
                        <input type="hidden" name="action" value="form2">

                        <button type="submit" name="delete" value="<?= $row['id'] ?>">Delete</button>
                    </form>
                </td>
                <td>
                    <!-- update page link -->
                    <a href="update_table.php?id=<?= $row['id'] ?>">Edit</a>
                </td>
            </tr>
        <?php
        }
        ?>
    </table>
<?php
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>