<!-- sweet alert source -->
<head>
    <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

<?php
//delete from database code
require_once("connect.php");

if (isset($_POST['delete'])) {
    $id = $_POST['delete'];

    try {

        $query = "DELETE FROM user WHERE id=?";
        $statement = $conn->prepare($query);
        $statement->bindParam(1, $id);
        $query_execute = $statement->execute();
        //sweet alert code
        if ($query_execute) {
            echo '<script type="text/javascript">
            $(document).ready(function() {
                swal({
                    title: "USER deleted!",
                    text: "Suceess message sent!!",
                    icon: "success",
                    button: "Ok",
                    timer: 2000
                });
            });
        </script>';
        } else {
            echo '<script type="text/javascript">
            $(document).ready(function() {
                swal({
                    title: "failed to delete
                    !",
                    text: "failed message sent!!",
                    icon: "failed",
                    button: "Ok",
                    timer: 2000
                });
            });
        </script>';
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}
//////////////////////////////////////////////////////////////////////

