<?php
//delete database code
require_once("connect.php");

if (isset($_POST['delete'])) {
    $id = $_POST['delete'];

    try {

        $query = "DELETE FROM user WHERE id=?";
        $statement = $conn->prepare($query);
        $statement->bindParam(1, $id);
        $query_execute = $statement->execute();

        if ($query_execute) {
            echo "Deleted Successfully" . " " . '<a href="form.php">return to main page</a>';;
        } else {
            echo "Deleted failed";
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}
//////////////////////////////////////////////////////////////////////

//updata database code

if (isset($_POST['update'])) {
    $student_id = $_POST['student_id'];
    $name2 = $_POST['name'];
    $email2 = $_POST['email'];
    $address2 = $_POST['address'];
    $gender2 = $_POST['gender'];
    if (empty($name2) || empty($email2) || empty($gender2) || empty($address2)) {

        if (empty($name2) || empty($email2) || empty($address2) || empty($gender2) && !preg_match("/^[a-zA-Z-' ]*$/", $name2) && !filter_var($email2, FILTER_VALIDATE_EMAIL)) {
            echo "you must write the edit in the same constrains of first form";
        }
    } else {


        try {

            $query2 = "UPDATE user SET namee=:namee, email=:email, addresss=:addresss, gender=:gender WHERE id=:stud_id LIMIT 1";
            $statement2 = $conn->prepare($query2);
            $statement2->bindParam(':namee', $name2);
            $statement2->bindParam(':email', $email2);
            $statement2->bindParam(':addresss', $address2);
            $statement2->bindParam(':gender', $gender2);
            $statement2->bindParam(':stud_id', $student_id, PDO::PARAM_INT);
            $query_execute2 = $statement2->execute();

            if ($query_execute2) {
                echo "updated Successfully" . " " . '<a href="form.php">return to main page</a>';;
            } else {
                echo "Deleted failed";
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
}
