<?php
///connect db page
require_once("connect.php");

///insert users
try {
  $stmt = $conn->prepare("INSERT INTO user (namee, email, addresss,gender)
  VALUES (:namee, :email, :addresss, :gender)");
  $stmt->bindParam(':namee', $name);
  $stmt->bindParam(':email', $email);
  $stmt->bindParam(':addresss', $address);
  $stmt->bindParam(':gender', $gender);
  $stmt->execute();
} catch (PDOException $e) {
  echo $e->getMessage();
}
////////////////////////////////////////////////////////

//select users to put them in html table

try {
  $sql = "SELECT * FROM user";
  $sql2 = $conn->query($sql);
  //bring the inserted data
  $row = $sql2->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  echo $e->getMessage();
}
