<?php
///connect db 
require_once("connect.php");
////////////////////////////////////////////
///insert users code
try {
  $stmt = $conn->prepare("INSERT INTO user (namee, email, addresss,gender)
  VALUES (:namee, :email, :addresss, :gender)");
  $stmt->bindParam(':namee', $name);
  $stmt->bindParam(':email', $email);
  $stmt->bindParam(':addresss', $address);
  $stmt->bindParam(':gender', $gender);
  $stmt->execute();
} catch (PDOException $e) {
  echo $e->getMessage();
}
////////////////////////////////////////////////////////
