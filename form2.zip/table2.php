<?php
/// fetch data
if (isset($_POST["submit"])) {
    
$name = $_POST['name_of_antiquity'];
$id = $_POST['id'];
$age = $_POST['age'];
$made = $_POST['made'];
$query2 = $conn->prepare("select * From user2 WHERE id='$id' or antiquity LIKE '%$name%' or age='$age'or made='$made' ");
$query2->execute();
$data = $query2->fetchAll();
foreach ($data as $row) { 
echo " <table border='1' cellpadding='10' cellspacing='0'>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>age</th>
            <th>made</th>
        </tr>
    </thead>
        <tr>
            <td> $row[id] </td>
            <td>  $row[antiquity]</td>
            <td> $row[age]</td>
            <td>$row[made] </td>
        </tr>
    
</table>";}}

// /// fetch data
// if (isset($_POST["id"])&&isset($_POST["submit"])) {
    
//     $id = $_POST['id'];
//     $query2 = $conn->prepare("select id, age, made From user2 WHERE antiquity='$id' ");
//     $query2->execute();
//     $data = $query2->fetchAll();
//     foreach ($data as $row) { 
//     echo " <table border='1' cellpadding='10' cellspacing='0'>
//         <thead>
//             <tr>
//                 <th>ID</th>
//                 <th>Name</th>
//                 <th>age</th>
//                 <th>made</th>
//             </tr>
//         </thead>
//             <tr>
//                 <td> $id </td>
//                 <td> $row[antiquity] </td>
//                 <td> $row[age]</td>
//                 <td>$row[made] </td>
//             </tr>
        
//     </table>";}}
//     if (isset($_POST["agec"])&&isset($_POST["submit"])) {
    
//         $id = $_POST['id'];
//         $query2 = $conn->prepare("select id, age, made From user2 WHERE antiquity='$id' ");
//         $query2->execute();
//         $data = $query2->fetchAll();
//         foreach ($data as $row) { 
//         echo " <table border='1' cellpadding='10' cellspacing='0'>
//             <thead>
//                 <tr>
//                     <th>ID</th>
//                     <th>Name</th>
//                     <th>age</th>
//                     <th>made</th>
//                 </tr>
//             </thead>
//                 <tr>
//                     <td> $id </td>
//                     <td> $row[antiquity] </td>
//                     <td> $row[age]</td>
//                     <td>$row[made] </td>
//                 </tr>
            
//         </table>";}}
//         if (isset($_POST["id"])&&isset($_POST["submit"])) {
    
//             $id = $_POST['id'];
//             $query2 = $conn->prepare("select id, age, made From user2 WHERE antiquity='$id' ");
//             $query2->execute();
//             $data = $query2->fetchAll();
//             foreach ($data as $row) { 
//             echo " <table border='1' cellpadding='10' cellspacing='0'>
//                 <thead>
//                     <tr>
//                         <th>ID</th>
//                         <th>Name</th>
//                         <th>age</th>
//                         <th>made</th>
//                     </tr>
//                 </thead>
//                     <tr>
//                         <td> $id </td>
//                         <td> $row[antiquity] </td>
//                         <td> $row[age]</td>
//                         <td>$row[made] </td>
//                     </tr>
                
//             </table>";}}