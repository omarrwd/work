<?php
require_once("connect.php");
$query = $conn->prepare('select id, antiquity, age, made From user2');
$query->execute();
$data = $query->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">

<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="">
</head>

<body>
    <?php $antiquity_id = "";
    $antiquity_name = ""; ?>
    <p>The selected element from database.</p>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

        <label for="id">select id:</label>
        <input type="text" name="id" value="<?php echo $antiquity_id ?>">
        <br><br>
        <label for="name_of_antiquity">select name:</label>
        <input type="text" name="name_of_antiquity" value="<?php echo $antiquity_name  ?>">
        <br><br>
        <label for="age">select age:</label>
        <select name="age">
            <option>--SELECT AGE--</option>
            <?php foreach ($data as $row) { ?>
                <option><?= $row["age"] ?></option>
            <?php } ?>
        </select>
        <br><br>
        <label for="made">select made:</label>
        <select name="made">
            <option>--SELECT MADE--</option>
            <?php foreach ($data as $row) { ?>
                <option><?= $row["made"] ?></option>
            <?php } ?>
        </select>
        <br><br>
        <input type="submit" name="submit" value="search">
    </form>
    <?php
    require_once("table2.php");


    ?>
</body>

</html>